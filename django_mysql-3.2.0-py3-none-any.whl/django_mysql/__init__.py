__author__ = 'Adam Johnson'
__email__ = 'me@adamj.eu'
__version__ = '3.2.0'


default_app_config = 'django_mysql.apps.MySQLConfig'
